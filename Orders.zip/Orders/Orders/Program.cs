﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orders
{
    class Program
    {
        static void Main(string[] args)
        {
            products p1 = new products();
            int opt = Convert.ToInt32(Console.ReadLine());
            while (opt == 100)
            {

                Console.WriteLine("select items to place order");
                opt = Convert.ToInt32(Console.ReadLine());
            }
             while (opt != 100)
                {
                    switch (opt)
                    {
                        

                    case 1:
                            starters s1 = new starters();
                            break;
                        case 2:
                            maincourse m1 = new maincourse();
                            break;
                        case 3:
                            desserts d1 = new desserts();
                            break;
                        default:
                            Console.WriteLine("enter a valid input");
                            break;
                    }
                    opt = Convert.ToInt32(Console.ReadLine());
                }



            Console.WriteLine(p1.total);
            






        }
    }
}
