﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orders
{
    class maincourse : products
    {
        public maincourse()
        {

        }
        protected override void options()
        {
            Dictionary<int, string> dict = new Dictionary<int, string>();
            dict.Add(150, "egg biryani         ");
            dict.Add(200, "chicken biryani     ");
            dict.Add(120, "biryani rice        ");
            dict.Add(20, "Roti                 ");
            dict.Add(140, "Paneer butter masala");
            dict.Add(160, "malai kofta         ");

            show(dict);

            choose(dict);

        }

    }
}
