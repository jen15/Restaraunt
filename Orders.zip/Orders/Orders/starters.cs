﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orders
{
    class starters : products
    {
        public starters()
        {
         //   select();
        }
       protected override void options()
        {
          /*  Dictionary<int, string> numb = new Dictionary<int, string>();
            numb.Add(1, "babycorn chilly");
            numb.Add(2, "french fries   ");
            numb.Add(3, "panner tikka   ");
            numb.Add(4, "tomato soup     ");
            numb.Add(5, "manchow soup   ");*/

            Dictionary<int, string> dict = new Dictionary<int, string>();
            dict.Add(150, "babycorn chilly");
            dict.Add(200, "french fries   ");
            dict.Add(120, "panner tikka   ");
            dict.Add(90, "tomato soup     ");
            dict.Add(110, "manchow soup   ");


            show(dict);
            choose(dict);


            }

       
        }
        
        
    }

