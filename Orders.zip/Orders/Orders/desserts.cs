﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orders
{
    class desserts : products
    {
        public desserts()
        {

        }
        protected override void options()
        {
            Dictionary<int, string> dict = new Dictionary<int, string>();
            dict.Add(150, "Almond choco fudge     ");
            dict.Add(200, "DBC (death by chocolate");
            dict.Add(90, "malai lassi             ");
            dict.Add(80, "almond choco shake      ");
            dict.Add(170, "Sundae ice-cream       ");

            show(dict);

            choose(dict);
        }

    }
}
