﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Orders
{
    class products
    {
        public int total = 0;
        public products()
        {

            Categories();

        }
       void  Categories()
        {
            Console.WriteLine("Please select from options below (enter no. corresponding to choice");
            options();
           
       }
        protected virtual  void options()

             
        {
            Console.WriteLine("                                 MAIN MENU                            ");
            Console.WriteLine("1" + "  Starters");
            Console.WriteLine("2" + "  Main Course");
            Console.WriteLine("3" + "  Desserts");
            Console.WriteLine("Press 100 to place order");




        }

       protected void show(Dictionary<int , string> dict)

        {
            Console.WriteLine("sl.no  " + "      name " + "               Price  ");
            int count = 1;
            foreach (KeyValuePair<int, string> item in dict)

            {
                
                Console.Write(count++ + "        ");
                Console.WriteLine(item.Value + "      " + item.Key);
            }
            Console.WriteLine("Press 0 to return to categories or main menu");
            Console.WriteLine("Press 100 to place order");


        }

        protected void choose(Dictionary<int, string> dict)
        {
            int opt = Convert.ToInt32(Console.ReadLine());
            while (opt == 100)
            {
                Console.WriteLine("select items to place order");
                opt = Convert.ToInt32(Console.ReadLine());
            }
            while (opt != 100)
            {
                if (opt == 0)
                   options();

                if (opt > dict.Count)
                    Console.WriteLine("enter a valid input");
                else
                    total = total + dict.Keys.ElementAt(opt - 1);

                opt = Convert.ToInt32(Console.ReadLine());



            }

        }

    }
}
